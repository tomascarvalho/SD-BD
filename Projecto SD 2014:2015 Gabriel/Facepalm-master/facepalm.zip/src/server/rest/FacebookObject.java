package server.rest;

public class FacebookObject implements IFacebookObject {

	private String id;
	private String name;
	
	public String getID() {
		return id;
	}
	
	public String getName() {
		return name;
	}

}
