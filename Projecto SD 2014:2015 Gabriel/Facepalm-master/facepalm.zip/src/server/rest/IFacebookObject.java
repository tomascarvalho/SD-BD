package server.rest;

public interface IFacebookObject {
	
	public String getID();
	public String getName();
}
