package websocket.notifications;

public class DataObject {

	public int target = 0;
	public String data = "";
	public String schedule = "";
	public String attaches = "";
	
}
